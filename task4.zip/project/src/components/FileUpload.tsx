import React, { useCallback } from 'react';
import { Upload, FileText, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
  onSampleData: () => void;
  isLoading: boolean;
}

export default function FileUpload({ onFileSelect, onSampleData, isLoading }: FileUploadProps) {
  const handleDrop = useCallback((e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const files = Array.from(e.dataTransfer.files);
    const csvFile = files.find(file => file.type === 'text/csv' || file.name.endsWith('.csv'));
    if (csvFile) {
      onFileSelect(csvFile);
    }
  }, [onFileSelect]);

  const handleFileInput = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onFileSelect(file);
    }
  }, [onFileSelect]);

  return (
    <div className="bg-white rounded-xl shadow-lg p-8 border border-gray-200">
      <div className="text-center">
        <h2 className="text-2xl font-bold text-gray-900 mb-4">Upload Social Media Data</h2>
        <p className="text-gray-600 mb-8">
          Upload a CSV file containing social media posts or use our sample dataset to get started
        </p>
        
        <div
          className="border-2 border-dashed border-blue-300 rounded-lg p-12 mb-6 transition-colors hover:border-blue-400 hover:bg-blue-50"
          onDrop={handleDrop}
          onDragOver={(e) => e.preventDefault()}
        >
          <Upload className="mx-auto h-12 w-12 text-blue-500 mb-4" />
          <p className="text-lg font-medium text-gray-900 mb-2">
            Drop your CSV file here or
          </p>
          <label className="inline-block">
            <span className="bg-blue-600 text-white px-6 py-3 rounded-lg cursor-pointer hover:bg-blue-700 transition-colors">
              Browse Files
            </span>
            <input
              type="file"
              accept=".csv"
              onChange={handleFileInput}
              className="hidden"
              disabled={isLoading}
            />
          </label>
        </div>
        
        <div className="flex items-center justify-center space-x-4 mb-6">
          <div className="h-px bg-gray-300 flex-1"></div>
          <span className="text-gray-500 font-medium">OR</span>
          <div className="h-px bg-gray-300 flex-1"></div>
        </div>
        
        <button
          onClick={onSampleData}
          disabled={isLoading}
          className="bg-gradient-to-r from-purple-600 to-pink-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-pink-700 transition-all transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <FileText className="inline w-5 h-5 mr-2" />
          Use Sample Dataset
        </button>
        
        <div className="mt-8 p-4 bg-blue-50 rounded-lg border border-blue-200">
          <div className="flex items-start space-x-3">
            <AlertCircle className="w-5 h-5 text-blue-600 mt-0.5 flex-shrink-0" />
            <div className="text-sm text-blue-800">
              <p className="font-semibold mb-1">Expected CSV Format:</p>
              <p>Your CSV should include columns like: text/comment, brand/company, topic/category, date/timestamp, platform/source</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}