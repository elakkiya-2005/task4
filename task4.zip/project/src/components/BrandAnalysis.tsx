import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface BrandAnalysisProps {
  brands: Array<{
    name: string;
    count: number;
    avgSentiment: number;
  }>;
  topics: Array<{
    name: string;
    count: number;
    avgSentiment: number;
  }>;
}

export default function BrandAnalysis({ brands, topics }: BrandAnalysisProps) {
  const getSentimentIcon = (score: number) => {
    if (score > 0.1) return <TrendingUp className="w-4 h-4 text-green-500" />;
    if (score < -0.1) return <TrendingDown className="w-4 h-4 text-red-500" />;
    return <Minus className="w-4 h-4 text-gray-500" />;
  };

  const getSentimentColor = (score: number) => {
    if (score > 0.1) return 'text-green-600';
    if (score < -0.1) return 'text-red-600';
    return 'text-gray-600';
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
      {/* Brand Analysis */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Top Brands by Mention</h3>
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={brands.slice(0, 8)} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" stroke="#6b7280" fontSize={12} />
              <YAxis 
                type="category" 
                dataKey="name" 
                stroke="#6b7280" 
                fontSize={12}
                width={80}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  color: '#ffffff',
                  border: 'none',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="count" 
                fill="#3B82F6"
                radius={[0, 4, 4, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        <div className="space-y-3">
          <h4 className="font-semibold text-gray-900">Sentiment Scores</h4>
          {brands.slice(0, 5).map(brand => (
            <div key={brand.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="font-medium text-gray-800">{brand.name}</span>
              <div className="flex items-center space-x-2">
                {getSentimentIcon(brand.avgSentiment)}
                <span className={`font-semibold ${getSentimentColor(brand.avgSentiment)}`}>
                  {brand.avgSentiment > 0 ? '+' : ''}{(brand.avgSentiment * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Topic Analysis */}
      <div className="bg-white rounded-xl shadow-lg p-6 border border-gray-200">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Top Topics by Discussion</h3>
        <div className="h-80 mb-6">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={topics.slice(0, 8)} layout="horizontal">
              <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
              <XAxis type="number" stroke="#6b7280" fontSize={12} />
              <YAxis 
                type="category" 
                dataKey="name" 
                stroke="#6b7280" 
                fontSize={12}
                width={100}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1f2937',
                  color: '#ffffff',
                  border: 'none',
                  borderRadius: '8px'
                }}
              />
              <Bar 
                dataKey="count" 
                fill="#8B5CF6"
                radius={[0, 4, 4, 0]}
              />
            </BarChart>
          </ResponsiveContainer>
        </div>
        
        <div className="space-y-3">
          <h4 className="font-semibold text-gray-900">Sentiment Scores</h4>
          {topics.slice(0, 5).map(topic => (
            <div key={topic.name} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="font-medium text-gray-800">{topic.name}</span>
              <div className="flex items-center space-x-2">
                {getSentimentIcon(topic.avgSentiment)}
                <span className={`font-semibold ${getSentimentColor(topic.avgSentiment)}`}>
                  {topic.avgSentiment > 0 ? '+' : ''}{(topic.avgSentiment * 100).toFixed(1)}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}