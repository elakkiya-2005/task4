export interface SocialMediaPost {
  id: string;
  text: string;
  brand?: string;
  topic?: string;
  timestamp: Date;
  platform?: string;
  location?: string;
  sentiment?: 'positive' | 'negative' | 'neutral';
  sentimentScore?: number;
  engagement?: number;
}

export interface SentimentAnalysis {
  sentiment: 'positive' | 'negative' | 'neutral';
  score: number;
  confidence: number;
}

export interface AnalyticsData {
  totalPosts: number;
  sentimentBreakdown: {
    positive: number;
    negative: number;
    neutral: number;
  };
  averageScore: number;
  topBrands: Array<{ name: string; count: number; avgSentiment: number }>;
  topTopics: Array<{ name: string; count: number; avgSentiment: number }>;
  timeSeriesData: Array<{ date: string; positive: number; negative: number; neutral: number }>;
}