import Papa from 'papaparse';
import { SocialMediaPost, AnalyticsData } from '../types';
import { analyzeSentiment } from './sentimentAnalysis';
import { format, parseISO, subDays, isValid } from 'date-fns';

export function parseCSVData(csvText: string): Promise<SocialMediaPost[]> {
  return new Promise((resolve, reject) => {
    Papa.parse(csvText, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        try {
          const posts: SocialMediaPost[] = results.data.map((row: any, index: number) => {
            // Try to extract text from various possible column names
            const text = row.text || row.comment || row.message || row.content || row.tweet || row.post || '';
            
            // Parse date from various formats
            let timestamp = new Date();
            const dateField = row.date || row.timestamp || row.created_at || row.time;
            if (dateField) {
              const parsed = new Date(dateField);
              if (isValid(parsed)) {
                timestamp = parsed;
              }
            }
            
            // Analyze sentiment
            const sentimentAnalysis = analyzeSentiment(text);
            
            return {
              id: row.id || `post_${index}`,
              text,
              brand: row.brand || row.company || '',
              topic: row.topic || row.category || row.subject || '',
              timestamp,
              platform: row.platform || row.source || 'unknown',
              location: row.location || row.country || row.region || '',
              sentiment: sentimentAnalysis.sentiment,
              sentimentScore: sentimentAnalysis.score,
              engagement: parseInt(row.likes || row.shares || row.engagement || '0', 10)
            };
          });
          
          resolve(posts.filter(post => post.text.trim().length > 0));
        } catch (error) {
          reject(error);
        }
      },
      error: (error) => {
        reject(error);
      }
    });
  });
}

export function generateAnalytics(posts: SocialMediaPost[]): AnalyticsData {
  const totalPosts = posts.length;
  
  // Sentiment breakdown
  const sentimentBreakdown = posts.reduce(
    (acc, post) => {
      acc[post.sentiment!]++;
      return acc;
    },
    { positive: 0, negative: 0, neutral: 0 }
  );
  
  // Average sentiment score
  const averageScore = posts.reduce((sum, post) => sum + (post.sentimentScore || 0), 0) / totalPosts;
  
  // Top brands analysis
  const brandStats = posts.reduce((acc, post) => {
    if (post.brand) {
      if (!acc[post.brand]) {
        acc[post.brand] = { count: 0, totalScore: 0 };
      }
      acc[post.brand].count++;
      acc[post.brand].totalScore += post.sentimentScore || 0;
    }
    return acc;
  }, {} as Record<string, { count: number; totalScore: number }>);
  
  const topBrands = Object.entries(brandStats)
    .map(([name, stats]) => ({
      name,
      count: stats.count,
      avgSentiment: stats.totalScore / stats.count
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
  
  // Top topics analysis
  const topicStats = posts.reduce((acc, post) => {
    if (post.topic) {
      if (!acc[post.topic]) {
        acc[post.topic] = { count: 0, totalScore: 0 };
      }
      acc[post.topic].count++;
      acc[post.topic].totalScore += post.sentimentScore || 0;
    }
    return acc;
  }, {} as Record<string, { count: number; totalScore: number }>);
  
  const topTopics = Object.entries(topicStats)
    .map(([name, stats]) => ({
      name,
      count: stats.count,
      avgSentiment: stats.totalScore / stats.count
    }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 10);
  
  // Time series data (last 30 days)
  const timeSeriesData = [];
  for (let i = 29; i >= 0; i--) {
    const date = subDays(new Date(), i);
    const dateStr = format(date, 'yyyy-MM-dd');
    
    const dayPosts = posts.filter(post => 
      format(post.timestamp, 'yyyy-MM-dd') === dateStr
    );
    
    const daySentiment = dayPosts.reduce(
      (acc, post) => {
        acc[post.sentiment!]++;
        return acc;
      },
      { positive: 0, negative: 0, neutral: 0 }
    );
    
    timeSeriesData.push({
      date: format(date, 'MMM dd'),
      ...daySentiment
    });
  }
  
  return {
    totalPosts,
    sentimentBreakdown,
    averageScore,
    topBrands,
    topTopics,
    timeSeriesData
  };
}

export function generateSampleData(): SocialMediaPost[] {
  const brands = ['Apple', 'Samsung', 'Google', 'Microsoft', 'Tesla', 'Netflix', 'Amazon', 'Meta'];
  const topics = ['Product Launch', 'Customer Service', 'Innovation', 'Pricing', 'Quality', 'User Experience'];
  const platforms = ['Twitter', 'Facebook', 'Instagram', 'LinkedIn', 'Reddit'];
  
  const sampleTexts = [
    "I absolutely love the new features! Best update ever.",
    "This product is amazing, highly recommend to everyone.",
    "Great customer service, they solved my issue quickly.",
    "Not impressed with the quality, expected much better.",
    "The pricing is way too high for what you get.",
    "Terrible experience, would not buy again.",
    "Outstanding innovation, this changes everything!",
    "Good value for money, satisfied with my purchase.",
    "The user interface is confusing and hard to navigate.",
    "Excellent build quality, very impressed with durability.",
    "Poor customer support, took forever to get help.",
    "Revolutionary technology, this is the future!",
    "Mediocre product, nothing special about it.",
    "Fantastic design and great performance overall.",
    "Disappointing update, many bugs and issues.",
    "Love the sleek design and intuitive interface.",
    "Overpriced and underwhelming, not worth it.",
    "Incredible value, exceeded all my expectations.",
    "Buggy software, needs serious improvements.",
    "Perfect for my needs, couldn't be happier!"
  ];
  
  return Array.from({ length: 500 }, (_, i) => {
    const text = sampleTexts[Math.floor(Math.random() * sampleTexts.length)];
    const sentiment = analyzeSentiment(text);
    
    return {
      id: `sample_${i}`,
      text,
      brand: brands[Math.floor(Math.random() * brands.length)],
      topic: topics[Math.floor(Math.random() * topics.length)],
      timestamp: new Date(Date.now() - Math.random() * 30 * 24 * 60 * 60 * 1000),
      platform: platforms[Math.floor(Math.random() * platforms.length)],
      location: `City ${Math.floor(Math.random() * 10)}`,
      sentiment: sentiment.sentiment,
      sentimentScore: sentiment.score,
      engagement: Math.floor(Math.random() * 1000)
    };
  });
}