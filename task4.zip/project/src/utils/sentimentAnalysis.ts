const positiveWords = [
  'love', 'great', 'excellent', 'amazing', 'fantastic', 'wonderful', 'awesome',
  'good', 'best', 'perfect', 'beautiful', 'outstanding', 'brilliant', 'superb',
  'incredible', 'fabulous', 'magnificent', 'remarkable', 'impressive', 'delightful',
  'happy', 'satisfied', 'pleased', 'excited', 'thrilled', 'grateful', 'recommend',
  'positive', 'success', 'win', 'winner', 'victory', 'achieve', 'accomplish',
  'like', 'enjoy', 'appreciate', 'admire', 'praise', 'celebrate', 'smile',
  'laugh', 'joy', 'comfortable', 'smooth', 'easy', 'helpful', 'friendly'
];

const negativeWords = [
  'hate', 'bad', 'terrible', 'awful', 'horrible', 'disgusting', 'pathetic',
  'worst', 'useless', 'broken', 'disappointed', 'angry', 'frustrated', 'annoyed',
  'sad', 'upset', 'furious', 'disgusted', 'outraged', 'shocked', 'appalled',
  'fail', 'failure', 'problem', 'issue', 'bug', 'error', 'crash', 'slow',
  'expensive', 'overpriced', 'cheap', 'fake', 'scam', 'waste', 'regret',
  'complain', 'complaint', 'refund', 'cancel', 'unsubscribe', 'block',
  'difficult', 'hard', 'impossible', 'confusing', 'complicated', 'boring'
];

const intensifiers = {
  'very': 1.5,
  'really': 1.4,
  'extremely': 1.8,
  'absolutely': 1.7,
  'completely': 1.6,
  'totally': 1.5,
  'quite': 1.2,
  'rather': 1.1,
  'somewhat': 0.8,
  'slightly': 0.7,
  'barely': 0.5,
  'hardly': 0.4
};

const negators = ['not', 'no', 'never', 'neither', 'nobody', 'nothing', 'nowhere', 'without'];

export function analyzeSentiment(text: string): { sentiment: 'positive' | 'negative' | 'neutral'; score: number; confidence: number } {
  const words = text.toLowerCase().match(/\b\w+\b/g) || [];
  let score = 0;
  let wordCount = 0;
  let intensity = 1;
  let negated = false;
  
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    
    // Check for intensifiers
    if (intensifiers[word]) {
      intensity = intensifiers[word];
      continue;
    }
    
    // Check for negators
    if (negators.includes(word)) {
      negated = true;
      continue;
    }
    
    // Reset negation after 3 words
    if (negated && i > 0 && !negators.includes(words[i - 1]) && !negators.includes(words[i - 2])) {
      negated = false;
    }
    
    // Calculate sentiment for current word
    let wordScore = 0;
    if (positiveWords.includes(word)) {
      wordScore = 1;
    } else if (negativeWords.includes(word)) {
      wordScore = -1;
    }
    
    if (wordScore !== 0) {
      wordScore *= intensity;
      if (negated) {
        wordScore *= -1;
      }
      score += wordScore;
      wordCount++;
      intensity = 1; // Reset intensity after use
      negated = false; // Reset negation after use
    }
  }
  
  const normalizedScore = wordCount > 0 ? score / wordCount : 0;
  const confidence = Math.min(wordCount / 10, 1); // Confidence based on number of sentiment words
  
  let sentiment: 'positive' | 'negative' | 'neutral';
  if (normalizedScore > 0.1) {
    sentiment = 'positive';
  } else if (normalizedScore < -0.1) {
    sentiment = 'negative';
  } else {
    sentiment = 'neutral';
  }
  
  return {
    sentiment,
    score: Math.max(-1, Math.min(1, normalizedScore)),
    confidence
  };
}